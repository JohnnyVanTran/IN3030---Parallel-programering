import java.util.Arrays;

public class Main{
    public static void main(String[] args) {
        int n = 0;
        int seed = 0;
        int threads = 0;
        try{
            n = Integer.parseInt(args[0]);
            seed = Integer.parseInt(args[1]);
            threads = Integer.parseInt(args[2]);
        }catch(Exception e){
            System.out.println("write in this format: java Main n(number of points) seed threads(number of threads)");
            System.out.println("Example: java Testprog 1000 420 2");
            return;
        }
        //Sequential
        Sequential s = new Sequential(n,seed);
        float [] time0 = new float[7];
        IntList res = null;
        for (int i = 0; i<7;i++){
            time0[i] = System.nanoTime();
            res = s.calcHull();
            time0[i] = (System.nanoTime()-time0[i])/1000000;
        }
        Arrays.sort(time0);
        //Median
        System.out.println("Seq: time " + time0[3] + "ms");

        System.out.println("DONE");
        Oblig4Precode precode  =  new Oblig4Precode(s,res);
        precode.writeHullPoints();
        if (n <= 1000){
            System.out.println("Hull points:");
            precode.theCoHull.print();
            precode.drawGraph();
        }
    }
}